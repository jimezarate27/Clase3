/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase3.ejercicio6;

import javax.swing.JOptionPane;

/**
 *
 * @author USUARIO
 */
public class Clase3Ejercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int suma=0; 
        int aprovados=0;
        int max=0; 
        int min=100; 
        int aprovado=0;
        String lectura;
        int estudiantes;
        lectura=JOptionPane.showInputDialog("Digite una cantidad de estudiantes:");
        estudiantes=Integer.parseInt(lectura);
        
        
        for (int x = 0; x<estudiantes; x++){
            String lectura2;
            int notas;
            lectura2=JOptionPane.showInputDialog("Digite la nota del cada estudiante:");
            notas=Integer.parseInt(lectura2);
            
            suma+=notas;
                    
            if (notas>=max){
                max=notas;
            }
                if (notas<=min){
                    min=notas;
                }
                    if (notas>=70){
                        aprovado++;
                    }
                      
                double prom = (double) suma / estudiantes;
                System.out.println("Promedio:" +prom+"\nNota maxima:"+max+"\nNota minima:"+min+"\nAprovados:"+aprovado);
                if ( notas<0){
                int menor = 0;
                }
                        
                    }
    }
}
