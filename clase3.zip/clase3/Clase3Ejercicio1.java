/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase3.ejercicio1;

/**
 *
 * @author USUARIO
 */
public class Clase3Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       for (int i = 0; i < 4; i++){
           for (int j = 0; j < 5; j++){
                System.out.print("@");
                
           }
           System.out.println("");
           
           }
    }
    
}
