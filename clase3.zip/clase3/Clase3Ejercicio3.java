/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase3.ejercicio3;

import javax.swing.JOptionPane;

/**
 *
 * @author USUARIO
 */
public class Clase3Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String lectura;
        int valor;
        lectura=JOptionPane.showInputDialog("Digite un numero:");
        valor=Integer.parseInt(lectura);
        for (int x = 0; x <= valor; x++){
            
             for (int j = 1; j <= x; j++){
                
                System.out.print("*");
            }
            System.out.println("");
        }
    }
    
}
